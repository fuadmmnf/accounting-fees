"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_pages_ApplicationLog_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/ApplicationLog.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/ApplicationLog.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var quasar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! quasar */ "./node_modules/quasar/src/index.esm.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: "ApplicationLog",
  data: function data() {
    return {
      confirmDeleteDialog: false,
      showDetail: false,
      selectedApplicationId: 0,
      selectedDate: quasar__WEBPACK_IMPORTED_MODULE_0__.date.formatDate(Date.now(), 'DD/MM/YYYY'),
      selectedCategory: 0,
      pagination: {
        page: 1,
        rowsPerPage: 10 // 0 means all rows

      },
      columns: [{
        name: 'category',
        align: 'left',
        label: 'Category' // field: row => row.category.name,

      }, {
        name: 'amount',
        align: 'left',
        label: 'Property Value' // field: row => row.amount,

      }, {
        name: 'fees',
        align: 'left',
        label: 'Fees',
        style: 'width: 50%' // field: row => row.amount,

      }, {
        name: 'action',
        align: 'left',
        label: 'Action(s)',
        style: 'width: 10%' // field: row => row.amount,

      }],
      categories: [],
      applications: []
    };
  },
  computed: {
    getFilteredApplications: function getFilteredApplications() {
      var _this = this;

      return this.selectedCategory == 0 ? this.applications : this.applications.filter(function (a) {
        return a.category_id == _this.selectedCategory;
      });
    }
  },
  watch: {
    selectedDate: function selectedDate(val) {
      this.loadApplications();
    }
  },
  mounted: function mounted() {
    this.loadCategories();
    this.loadApplications();
  },
  methods: {
    loadCategories: function loadCategories() {
      var _this2 = this;

      this.$axios.get('/api/categories').then(function (res) {
        _this2.categories = [{
          value: 0,
          label: 'সকল ধরন'
        }].concat(_toConsumableArray(res.data.map(function (c) {
          return {
            value: c.id,
            label: c.name
          };
        })));
      });
    },
    loadApplications: function loadApplications() {
      var _this3 = this;

      this.$axios.get("/api/applications?date=".concat(this.selectedDate, "&category_id=").concat(this.selectedCategory)).then(function (res) {
        _this3.applications = res.data;
      });
    },
    deleteApplication: function deleteApplication() {
      var _this4 = this;

      this.$axios["delete"]("api/applications/".concat(this.selectedApplicationId)).then(function (res) {
        _this4.confirmDeleteDialog = false;

        _this4.loadApplications();
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/pages/ApplicationLog.vue":
/*!***********************************************!*\
  !*** ./resources/js/pages/ApplicationLog.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ApplicationLog_vue_vue_type_template_id_6de5eb9d_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ApplicationLog.vue?vue&type=template&id=6de5eb9d&scoped=true& */ "./resources/js/pages/ApplicationLog.vue?vue&type=template&id=6de5eb9d&scoped=true&");
/* harmony import */ var _ApplicationLog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ApplicationLog.vue?vue&type=script&lang=js& */ "./resources/js/pages/ApplicationLog.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ApplicationLog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ApplicationLog_vue_vue_type_template_id_6de5eb9d_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _ApplicationLog_vue_vue_type_template_id_6de5eb9d_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "6de5eb9d",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/ApplicationLog.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/ApplicationLog.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/pages/ApplicationLog.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ApplicationLog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ApplicationLog.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/ApplicationLog.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ApplicationLog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/ApplicationLog.vue?vue&type=template&id=6de5eb9d&scoped=true&":
/*!******************************************************************************************!*\
  !*** ./resources/js/pages/ApplicationLog.vue?vue&type=template&id=6de5eb9d&scoped=true& ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ApplicationLog_vue_vue_type_template_id_6de5eb9d_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ApplicationLog_vue_vue_type_template_id_6de5eb9d_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ApplicationLog_vue_vue_type_template_id_6de5eb9d_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ApplicationLog.vue?vue&type=template&id=6de5eb9d&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/ApplicationLog.vue?vue&type=template&id=6de5eb9d&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/ApplicationLog.vue?vue&type=template&id=6de5eb9d&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/ApplicationLog.vue?vue&type=template&id=6de5eb9d&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "q-pa-md" },
    [
      _c("q-table", {
        attrs: {
          title: "Deeds (" + _vm.getFilteredApplications.length + ")",
          data: _vm.getFilteredApplications,
          columns: _vm.columns,
          "rows-per-page-options": [10],
          pagination: _vm.pagination,
        },
        on: {
          "update:pagination": function ($event) {
            _vm.pagination = $event
          },
        },
        scopedSlots: _vm._u([
          {
            key: "body",
            fn: function (props) {
              return [
                _c(
                  "q-tr",
                  { attrs: { props: props } },
                  [
                    _c("q-td", { key: "category", attrs: { props: props } }, [
                      _vm._v(
                        "\n                        " +
                          _vm._s(props.row.category.name) +
                          "\n                    "
                      ),
                    ]),
                    _vm._v(" "),
                    _c("q-td", { key: "amount", attrs: { props: props } }, [
                      _vm._v(
                        "\n                        " +
                          _vm._s(props.row.amount) +
                          " tk\n                    "
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "q-td",
                      {
                        key: "fees",
                        attrs: { "auto-width": "", props: props },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "row" },
                          _vm._l(props.row.applicationfees, function (fee) {
                            return _c(
                              "q-chip",
                              {
                                key: fee.id,
                                staticClass:
                                  "col-md-5 col-xs-12 q-pr-sm q-pb-sm",
                                attrs: { size: "sm" },
                              },
                              [
                                _vm._v(
                                  _vm._s(
                                    (fee.field_id == null
                                      ? fee.optional_field_name
                                      : fee.field.name) +
                                      ": " +
                                      (fee.unit == 0
                                        ? (props.row.amount * fee.amount) /
                                          100.0
                                        : fee.amount) +
                                      " tk"
                                  )
                                ),
                              ]
                            )
                          }),
                          1
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "q-td",
                      { key: "action", attrs: { props: props } },
                      [
                        _c("q-btn", {
                          attrs: {
                            size: "sm",
                            color: "negative",
                            "text-color": "white",
                            icon: "delete",
                          },
                          on: {
                            click: function ($event) {
                              _vm.confirmDeleteDialog = true
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c(
                          "q-dialog",
                          {
                            key: props.row.id,
                            attrs: {
                              id: "confirmation-" + props.row.id,
                              persistent: "",
                            },
                            model: {
                              value: _vm.confirmDeleteDialog,
                              callback: function ($$v) {
                                _vm.confirmDeleteDialog = $$v
                              },
                              expression: "confirmDeleteDialog",
                            },
                          },
                          [
                            _c(
                              "q-card",
                              [
                                _c(
                                  "q-card-section",
                                  { staticClass: "row items-center" },
                                  [
                                    _c("span", { staticClass: "q-ml-sm" }, [
                                      _vm._v(
                                        "Are you sure you want to delete?"
                                      ),
                                    ]),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "q-card-actions",
                                  { attrs: { align: "right" } },
                                  [
                                    _c("q-btn", {
                                      directives: [
                                        {
                                          name: "close-popup",
                                          rawName: "v-close-popup",
                                        },
                                      ],
                                      attrs: {
                                        flat: "",
                                        label: "Cancel",
                                        color: "primary",
                                      },
                                    }),
                                    _vm._v(" "),
                                    _c("q-btn", {
                                      attrs: {
                                        flat: "",
                                        label: "Confirm",
                                        color: "primary",
                                      },
                                      on: {
                                        click: function () {
                                          _vm.selectedApplicationId =
                                            props.row.id
                                          _vm.deleteApplication()
                                        },
                                      },
                                    }),
                                  ],
                                  1
                                ),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ]
            },
          },
          {
            key: "top-right",
            fn: function () {
              return [
                _c(
                  "div",
                  { staticClass: "row" },
                  [
                    _c("q-input", {
                      staticClass: "col-md-6 q-pr-xs q-pb-md",
                      attrs: { dense: "", filled: "", label: "Date" },
                      scopedSlots: _vm._u([
                        {
                          key: "append",
                          fn: function () {
                            return [
                              _c(
                                "q-icon",
                                {
                                  staticClass: "cursor-pointer",
                                  attrs: { name: "event" },
                                },
                                [
                                  _c(
                                    "q-popup-proxy",
                                    {
                                      ref: "qDateProxy",
                                      attrs: {
                                        cover: "",
                                        "transition-show": "scale",
                                        "transition-hide": "scale",
                                      },
                                    },
                                    [
                                      _c(
                                        "q-date",
                                        {
                                          attrs: {
                                            "today-btn": "",
                                            mask: "DD/MM/YYYY",
                                          },
                                          model: {
                                            value: _vm.selectedDate,
                                            callback: function ($$v) {
                                              _vm.selectedDate = $$v
                                            },
                                            expression: "selectedDate",
                                          },
                                        },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "row items-center justify-end",
                                            },
                                            [
                                              _c("q-btn", {
                                                directives: [
                                                  {
                                                    name: "close-popup",
                                                    rawName: "v-close-popup",
                                                  },
                                                ],
                                                attrs: {
                                                  label: "Close",
                                                  color: "primary",
                                                  flat: "",
                                                },
                                              }),
                                            ],
                                            1
                                          ),
                                        ]
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ]
                          },
                          proxy: true,
                        },
                      ]),
                      model: {
                        value: _vm.selectedDate,
                        callback: function ($$v) {
                          _vm.selectedDate = $$v
                        },
                        expression: "selectedDate",
                      },
                    }),
                    _vm._v(" "),
                    _c("q-select", {
                      staticClass: "col-md-5 q-pb-sm q-pr-xs",
                      attrs: {
                        dense: "",
                        options: _vm.categories,
                        "option-label": "label",
                        "map-options": "",
                        "emit-value": "",
                        label: "Category Filter",
                      },
                      model: {
                        value: _vm.selectedCategory,
                        callback: function ($$v) {
                          _vm.selectedCategory = $$v
                        },
                        expression: "selectedCategory",
                      },
                    }),
                  ],
                  1
                ),
              ]
            },
            proxy: true,
          },
        ]),
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);