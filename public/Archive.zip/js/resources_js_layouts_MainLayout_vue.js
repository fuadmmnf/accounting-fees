"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_layouts_MainLayout_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/EssentialLink.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/EssentialLink.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'EssentialLink',
  props: {
    title: {
      type: String,
      required: true
    },
    caption: {
      type: String,
      "default": ''
    },
    link: {
      type: String | Object,
      "default": '#'
    },
    icon: {
      type: String,
      "default": ''
    },
    blank: {
      type: Boolean,
      "default": false
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/MainLayout.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/MainLayout.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_EssentialLink__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/EssentialLink */ "./resources/js/components/EssentialLink.vue");
/* harmony import */ var quasar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! quasar */ "./node_modules/quasar/src/index.esm.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'MainLayout',
  components: {
    EssentialLink: _components_EssentialLink__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      leftDrawerOpen: false,
      essentialLinks: [{
        title: 'List',
        caption: 'application list date|category wise',
        icon: 'table_chart',
        link: {
          name: 'log'
        },
        blank: false
      }, {
        title: 'Create',
        caption: 'create new application entry',
        icon: 'add',
        link: {
          name: 'create'
        },
        blank: false
      }, {
        title: 'Report',
        caption: 'daily | monthly | yearly accounting reports',
        icon: 'assignment',
        link: {
          name: 'report'
        },
        blank: false
      }],
      categoryForm: {
        name: ''
      },
      showCategoryCreateDialog: false
    };
  },
  methods: {
    createCategory: function createCategory() {
      var _this = this;

      this.$axios.post('/api/categories', this.categoryForm).then(function (res) {
        _this.categoryForm.name = '';
        quasar__WEBPACK_IMPORTED_MODULE_1__.Notify.create({
          message: 'Category Created Successfully!'
        });

        _this.$root.$emit('category-created');

        _this.showCategoryCreateDialog = false;
      });
    },
    logout: function logout() {
      localStorage.removeItem('user');
      this.$router.replace('/login');
    }
  }
});

/***/ }),

/***/ "./resources/js/components/EssentialLink.vue":
/*!***************************************************!*\
  !*** ./resources/js/components/EssentialLink.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _EssentialLink_vue_vue_type_template_id_049ae80d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./EssentialLink.vue?vue&type=template&id=049ae80d& */ "./resources/js/components/EssentialLink.vue?vue&type=template&id=049ae80d&");
/* harmony import */ var _EssentialLink_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EssentialLink.vue?vue&type=script&lang=js& */ "./resources/js/components/EssentialLink.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _EssentialLink_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _EssentialLink_vue_vue_type_template_id_049ae80d___WEBPACK_IMPORTED_MODULE_0__.render,
  _EssentialLink_vue_vue_type_template_id_049ae80d___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/EssentialLink.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/layouts/MainLayout.vue":
/*!*********************************************!*\
  !*** ./resources/js/layouts/MainLayout.vue ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _MainLayout_vue_vue_type_template_id_5a6a1827___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MainLayout.vue?vue&type=template&id=5a6a1827& */ "./resources/js/layouts/MainLayout.vue?vue&type=template&id=5a6a1827&");
/* harmony import */ var _MainLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MainLayout.vue?vue&type=script&lang=js& */ "./resources/js/layouts/MainLayout.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _MainLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _MainLayout_vue_vue_type_template_id_5a6a1827___WEBPACK_IMPORTED_MODULE_0__.render,
  _MainLayout_vue_vue_type_template_id_5a6a1827___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/layouts/MainLayout.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/EssentialLink.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/components/EssentialLink.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EssentialLink_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./EssentialLink.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/EssentialLink.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EssentialLink_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/layouts/MainLayout.vue?vue&type=script&lang=js&":
/*!**********************************************************************!*\
  !*** ./resources/js/layouts/MainLayout.vue?vue&type=script&lang=js& ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_MainLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./MainLayout.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/MainLayout.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_MainLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/EssentialLink.vue?vue&type=template&id=049ae80d&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/EssentialLink.vue?vue&type=template&id=049ae80d& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EssentialLink_vue_vue_type_template_id_049ae80d___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EssentialLink_vue_vue_type_template_id_049ae80d___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EssentialLink_vue_vue_type_template_id_049ae80d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./EssentialLink.vue?vue&type=template&id=049ae80d& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/EssentialLink.vue?vue&type=template&id=049ae80d&");


/***/ }),

/***/ "./resources/js/layouts/MainLayout.vue?vue&type=template&id=5a6a1827&":
/*!****************************************************************************!*\
  !*** ./resources/js/layouts/MainLayout.vue?vue&type=template&id=5a6a1827& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_MainLayout_vue_vue_type_template_id_5a6a1827___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_MainLayout_vue_vue_type_template_id_5a6a1827___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_MainLayout_vue_vue_type_template_id_5a6a1827___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./MainLayout.vue?vue&type=template&id=5a6a1827& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/MainLayout.vue?vue&type=template&id=5a6a1827&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/EssentialLink.vue?vue&type=template&id=049ae80d&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/EssentialLink.vue?vue&type=template&id=049ae80d& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "q-item",
    {
      attrs: {
        clickable: "",
        to: _vm.blank ? null : _vm.link,
        target: _vm.blank ? "_blank" : "",
        tag: _vm.blank ? "a" : null,
        href: _vm.blank ? _vm.link : null,
        active: _vm.link.name === _vm.$route.name,
      },
    },
    [
      _vm.icon
        ? _c(
            "q-item-section",
            { attrs: { avatar: "" } },
            [_c("q-icon", { attrs: { name: _vm.icon } })],
            1
          )
        : _vm._e(),
      _vm._v(" "),
      _c(
        "q-item-section",
        [
          _c("q-item-label", [_vm._v(_vm._s(_vm.title))]),
          _vm._v(" "),
          _c("q-item-label", { attrs: { caption: "" } }, [
            _vm._v("\n      " + _vm._s(_vm.caption) + "\n    "),
          ]),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/MainLayout.vue?vue&type=template&id=5a6a1827&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/layouts/MainLayout.vue?vue&type=template&id=5a6a1827& ***!
  \*******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "q-layout",
    { attrs: { view: "lHh Lpr lFf" } },
    [
      _c(
        "q-header",
        { attrs: { elevated: "" } },
        [
          _c(
            "q-toolbar",
            [
              _c("q-btn", {
                attrs: {
                  flat: "",
                  dense: "",
                  round: "",
                  icon: "menu",
                  "aria-label": "Menu",
                },
                on: {
                  click: function ($event) {
                    _vm.leftDrawerOpen = !_vm.leftDrawerOpen
                  },
                },
              }),
              _vm._v(" "),
              _c("q-toolbar-title", [
                _vm._v("\n                Fees Accounting\n            "),
              ]),
              _vm._v(" "),
              _c(
                "div",
                [
                  _c("q-btn", {
                    staticClass: "q-mr-lg",
                    attrs: {
                      icon: "add",
                      to: { name: "create" },
                      color: "white",
                      "text-color": "primary",
                      label: "Create",
                    },
                  }),
                  _vm._v(" "),
                  _c("q-btn", {
                    staticClass: "q-mr-lg",
                    attrs: {
                      icon: "add",
                      color: "white",
                      "text-color": "primary",
                      label: "Category",
                    },
                    on: {
                      click: function ($event) {
                        _vm.showCategoryCreateDialog = true
                      },
                    },
                  }),
                  _vm._v(" "),
                  _c(
                    "q-dialog",
                    {
                      attrs: { persistent: "" },
                      model: {
                        value: _vm.showCategoryCreateDialog,
                        callback: function ($$v) {
                          _vm.showCategoryCreateDialog = $$v
                        },
                        expression: "showCategoryCreateDialog",
                      },
                    },
                    [
                      _c(
                        "q-card",
                        { staticStyle: { "min-width": "400px" } },
                        [
                          _c("q-card-section", [
                            _c("div", { staticClass: "text-h6" }, [
                              _vm._v("Create Category"),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("q-card-section", { staticClass: "q-pt-none" }, [
                            _c(
                              "div",
                              { staticClass: "row" },
                              [
                                _c("q-input", {
                                  staticClass: "col-10  q-pb-sm q-pr-sm",
                                  attrs: { dense: "", label: "Name" },
                                  model: {
                                    value: _vm.categoryForm.name,
                                    callback: function ($$v) {
                                      _vm.$set(_vm.categoryForm, "name", $$v)
                                    },
                                    expression: "categoryForm.name",
                                  },
                                }),
                              ],
                              1
                            ),
                          ]),
                          _vm._v(" "),
                          _c(
                            "q-card-actions",
                            {
                              staticClass: "text-primary",
                              attrs: { align: "right" },
                            },
                            [
                              _c("q-btn", {
                                directives: [
                                  {
                                    name: "close-popup",
                                    rawName: "v-close-popup",
                                  },
                                ],
                                attrs: { flat: "", label: "Cancel" },
                              }),
                              _vm._v(" "),
                              _c("q-btn", {
                                attrs: { flat: "", label: "Add" },
                                on: { click: _vm.createCategory },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("q-btn", {
                    attrs: { icon: "logout" },
                    on: { click: _vm.logout },
                  }),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "q-drawer",
        {
          attrs: {
            "show-if-above": "",
            bordered: "",
            "content-class": "bg-grey-1",
          },
          model: {
            value: _vm.leftDrawerOpen,
            callback: function ($$v) {
              _vm.leftDrawerOpen = $$v
            },
            expression: "leftDrawerOpen",
          },
        },
        [
          _c(
            "q-list",
            [
              _c(
                "q-item-label",
                { staticClass: "text-grey-8", attrs: { header: "" } },
                [_vm._v("\n                Essential Links\n            ")]
              ),
              _vm._v(" "),
              _vm._l(_vm.essentialLinks, function (link) {
                return _c(
                  "EssentialLink",
                  _vm._b({ key: link.title }, "EssentialLink", link, false)
                )
              }),
            ],
            2
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "q-page-container",
        [
          _c(
            "transition",
            {
              attrs: {
                appear: "",
                "enter-active-class": "animate__animated animate__zoomIn",
              },
            },
            [_c("router-view")],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);